/* locale.h - C locale (TanjaOS always runs the "C" locale) */
#ifndef _LOCALE_H
#define _LOCALE_H

#define LC_ALL      6
#define LC_COLLATE  0
#define LC_CTYPE    1
#define LC_MONETARY 2
#define LC_NUMERIC  3
#define LC_TIME     4

struct lconv {
    char *decimal_point;
    char *thousands_sep;
    char *grouping;
    char *int_curr_symbol;
    char *currency_symbol;
    char *mon_decimal_point;
    char *mon_thousands_sep;
    char *mon_grouping;
    char *positive_sign;
    char *negative_sign;
    char int_frac_digits;
    char frac_digits;
    char p_cs_precedes;
    char p_sep_by_space;
    char n_cs_precedes;
    char n_sep_by_space;
    char p_sign_posn;
    char n_sign_posn;
};

char *setlocale(int category, const char *locale);
struct lconv *localeconv(void);

#endif /* _LOCALE_H */
